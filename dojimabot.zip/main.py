import discord
import random
import asyncio

intents = discord.Intents.default()
intents.message_content = True

client = discord.Client(intents=intents)
adachi_line = ["Adachi.", "ADACHIII!!!", "Shutup Adachi.", "Adachi.."]


@client.event
async def on_ready():
  print(f'We have logged in as {client.user}')


@client.event
async def on_message(message):
  if message.author == client.user:
    return

  if message.content.startswith('adachi'):
    minTime = 1  #minimum time in seconds
    maxTime = 100  #maximum time in seconds
    
    await message.channel.send(random.choice(adachi_line))


client.run(
  'MTA2NTEzNDI3OTM1ODY4NTI3OA.GPfufA.Nf4i-9sh8Hqw_zkxCnhIEemANh_-ZWT1g7bx78')
